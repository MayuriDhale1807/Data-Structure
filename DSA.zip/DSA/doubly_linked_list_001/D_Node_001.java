package doubly_linked_list_001;

public class D_Node_001 
{
	D_Node_001 prev;
	int item;
	D_Node_001 next;
}