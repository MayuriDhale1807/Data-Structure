package tree_IN_PRE_POST;

public class Node_001 
{
	Node_001 left;
	int data;
	Node_001 right;
}
