package binary_search_tree_001;

public class Node 
{
	Node left;
	int data;
	Node right;
}
