package linked_list_001;
public class Node_001 
{
	int data001;		//data inside NODE is of type integer
	Node_001 next001;	//the address stored inside next001 is of type Node_001
}
