package javaOOps_assignment_01;

public class Ques14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
