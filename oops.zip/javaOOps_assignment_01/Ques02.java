package javaOOps_assignment_01;
import java.util.*;
public class Ques02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER ROLL NO.");
		int rollNo=sc.nextInt();
		System.out.println(rollNo);
		sc.close();
	}

}
