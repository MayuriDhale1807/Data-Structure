package assignment_class_interface_03_v_sir;

public class MathOperation 
{
	static int a,b;
	
	static int add(int a, int b)
	{
		return a+b;
	}
	static int subtract(int a, int b)
	{
		return a-b;
	}
	static int multiply(int a, int b)
	{
		return a*b;
	}
	static double power(int a, int b)
	{
		return Math.pow(a, b);
	}
}
