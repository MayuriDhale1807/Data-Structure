package assigment_class_interface_08_v_sir;

public class FacultyInfo 
{
	public static void main(String[] args) 
	{
		FullTimeFaculty ft = new FullTimeFaculty();
		PartTimeFaculty pt = new PartTimeFaculty();
		ft.input();
		pt.input();
	}
}
