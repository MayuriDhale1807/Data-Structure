package oct03_morning;

public class String02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str[]= {"#vishal","$Amit","Viraj kumar","Neha"};
		
		for(int i=0;i<str.length;i++)
		{
			System.out.println("str["+i+"] = "+str[i]);
		}
	}

}
