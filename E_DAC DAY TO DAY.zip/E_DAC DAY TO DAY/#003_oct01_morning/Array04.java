package oct01_morning;

public class Array04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a[]= {'A','b','c','D'};
		char a1[]=new char[] {'a','B','C','!'};
		for(char i: a)
		{
			System.out.println(i);
		}
		System.out.println();
		for(char i: a1)
		{
			System.out.println(i);
		}
	}
}
