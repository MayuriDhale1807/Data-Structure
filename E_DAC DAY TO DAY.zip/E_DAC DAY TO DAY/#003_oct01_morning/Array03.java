package oct01_morning;

public class Array03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("boolean coming");
		boolean ar[]=new boolean[3];
		for(boolean a: ar)
		{
			System.out.println(a);
		}
		System.out.println("int coming");
		int arr[]=new int[3];
		for(int a: arr)
		{
			System.out.println(a);
		}
		System.out.println("short coming");
		short arrr[]=new short[3];
		for(short a: arrr)
		{
			System.out.println(a);
		}
		System.out.println("long coming");
		long arrrr[]=new long[3];
		for(long a: arrrr)
		{
			System.out.println(a);
		}
		System.out.println("float coming");
		float arrrrr[]=new float[3];
		for(float a: arrrrr)
		{
			System.out.println(a);
		}
	}
}
