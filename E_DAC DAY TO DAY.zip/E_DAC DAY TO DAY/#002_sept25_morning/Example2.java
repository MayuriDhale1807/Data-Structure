package sep25_morning;

public class Example2 
{
	public static void main(String[] args)
	{
		double number= -10.6;
		Double num= 15.9;
		System.out.println(5);
		System.out.println(number);
		System.out.println(num);
	}
}

/*

5
-10.6
15.9

*/