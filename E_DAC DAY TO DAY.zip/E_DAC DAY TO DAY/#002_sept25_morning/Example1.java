package sep25_morning;

public class Example1
{
	public static void main(String[] args)
	{
		System.out.print('h'+'i');
		System.out.println();
		System.out.println("h"+"i");
	}
}


/*
 * OUTPUT

209
hi

*/

/*
ASCII values are used

a-z ->
A-Z ->
0-9 ->
special character

now a days unicode system are used
\u0000 -min
......
 \uffff -max
*/
