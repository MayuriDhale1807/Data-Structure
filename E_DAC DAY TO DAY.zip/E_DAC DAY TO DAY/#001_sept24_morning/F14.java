package sep24_morning;

public class F14 
{
	public static void main(String[] args)
	{
		
	}
}
