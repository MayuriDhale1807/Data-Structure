package sep24_morning;
/* started for loop, one of the three loops*/

//print first 10 natural no.

//this is also called 1D print via for loop.
public class F01 
{
	public static void main(String[] args)
	{
		for(int i=1;i<=10;i++)
		{
			System.out.print(i);
			//System.out.println(i+" ");
			//System.out.print(i+" $ ");
		}
	}
}


//	o/p: 1 2 3 4 5 6 7 8 9 10
